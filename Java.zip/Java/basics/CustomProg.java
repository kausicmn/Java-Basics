package basics;

import java.util.Scanner;

class NameNotFoundException extends Exception{
    NameNotFoundException(String msg){
         System.out.println(msg); 
    }
}
public class CustomProg {
  
   
 static void nameSearch(String[] names,String n)throws NameNotFoundException {
     boolean flag=false;
     for (int j=0;j<names.length;j++){
         if(n.equals(names[j])){
             flag=true;
         }
     }
         if (flag!=true)
             throw new NameNotFoundException("Customer name not in list");
            else
             System.out.println("Name found");
         
     
       
   }
  static String[] names=new String[5];
   public static void main(String[] args){
       System.out.println("Enter the names");
       Scanner sc=new Scanner(System.in);
       for (int i=0;i<5;i++){
           names[i]=sc.next();
       }
       System.out.println("Enter the name to search");
       String n=sc.next();
       try{
       nameSearch(names,n);
       }
       catch(NameNotFoundException ne){
           System.out.println(ne);
       }
       finally{
           System.out.println("In finally");
          
       }
       System.out.println("End");
   }
   
}