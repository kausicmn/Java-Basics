package basics;
import java.util.*;
public class OwnException extends Exception {
	OwnException(String msg)
	{
		System.out.println(msg);
	}
	

	
	 
	 static void check(String m[],String n)throws OwnException
	{
		 int f=0;
		
		for(int i=0;i<m.length;i++)
		{
			if(n.equals(m[i]))
			{
				f=1;
			}
			
		}
		if(f==0)
		{
			throw new OwnException(" not found");
		}
		if(f==1)
		{
			System.out.println(" found");
		}
	}	
	 
	static String m[]=new String[5];
	public static void main(String args[])
	{
		int i;
		String n;
		System.out.println("enter the names");
		Scanner ob=new Scanner(System.in);
		for(i=0;i<5;i++)
		{
			m[i]=ob.next();	
		}
		
		System.out.println("enter the name to be searched");
		n=ob.next();
		
		try {
		check(m,n);
		}
		catch(OwnException e){
			System.out.println("null");
			
		}
		finally
		{
			System.out.println("done");
			
		}
	}
	
}
