package basics;
abstract class qwerty
{
	String s="red";
  abstract void qwe(String m);
 
	abstract void area(int r);
}
class square extends qwerty
{
	
	double ar;
	void qwe(String m)
	{
		System.out.println(m);
	}

	void area(int r)
	{
		ar=3.14*r*r;
		System.out.println(ar);
	}
	
	

	
}
public class abst {

	public static void main(String args[])
	{
		qwerty q=new square();
		q.qwe("white");
		q.area(2);
		
		
		
	}
}
