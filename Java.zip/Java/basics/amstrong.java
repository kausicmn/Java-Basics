package basics;
import java.util.*;
public class amstrong {
int n,m;
int k=0;
int r;
static int temp;
void ams(int n)
{
	
	while(n!=0)
	{
	r=n%10;
	k=k+r*r*r;
	n=n/10;
	}
if(k==temp)
{	
	System.out.println("amstrong number");
}
else
{
	System.out.println(" not amstrong number");
}
}
public static void main(String args[]) 
{
	
int n;
	System.out.println("enter number");
	Scanner ob=new Scanner(System.in);
	n=ob.nextInt();
	temp=n;
	amstrong a=new amstrong();
	a.ams(n);
	
}
}
