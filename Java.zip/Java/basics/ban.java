package basics;
import java.util.*;
public class ban {
 static String name;
static String email;
static int phno,actno,balance;
static String acttype;
static Scanner ob= new Scanner(System.in);

 
void Deposit()
{
	System.out.println("enter the amount to be deposited");
	int dep=ob.nextInt();
	balance=balance+dep;
}
void withdraw()
{
	System.out.println("enter the amount to be withdraw");
	int with=ob.nextInt();
	balance=balance-with;
}
void details()
{
	System.out.println("name="+name);
	System.out.println("account type="+acttype);
	System.out.println("accno="+actno);
	System.out.println("email="+email);
	System.out.println("phno="+phno);
	System.out.println("bal="+balance);
}
	void checkbal()
	{
		System.out.println("bal="+balance);
		
}
	public static void main (String args[])
	{
		
		System.out.println("enter the name");
		name=ob.next();
		System.out.println("enter the account type");
		acttype=ob.next();
		System.out.println("enter the actno");
		actno=ob.nextInt();
		System.out.println("enter the initial balance");
		balance=ob.nextInt();
		System.out.println("enter the ph no");
		phno=ob.nextInt();
		System.out.println("enter the email");
		email=ob.next();
		
		
		 int n;
		
		System.out.println("Menu"+'\n'+"1.Deposit"+'\n'+"2.withdraw"+'\n'+"3.display details"+'\n'+"4.checkbal"+'\n'+"5.Exit");
		
		 
		do {
		System.out.println("enter your choice");
		 n=ob.nextInt();
		
		
		
		  switch(n)
		{
		case 1:
		{
		 ban b=new ban();
		 b.Deposit();
		 break;
		}
		case 2:
		{
		 ban b=new ban();
		 b.withdraw();
		 break;
		 
		}
		case 3:
		{
		 ban b=new ban();
		 b.details();
		 break;
		 
		}
		case 4:
		{
		
		 ban b=new ban();
		 b.checkbal();
		 break;
		}
		case 5:
		{
			System.out.println("exit");
			
			break;
		}
		}
		
		}while(n!=5);
	}
}

	
		
		
			
		
		
		
		

