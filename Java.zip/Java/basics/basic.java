package basics;
import java.util.Scanner;


public class basic {
	
		public static void main (String[]args)
		{
			int a,b,c,opt;
			String s;
			Scanner ob=new Scanner(System.in);
			System.out.println("enter the values");
			
			a=ob.nextInt();
			b=ob.nextInt();
			s=ob.next();
			
			
			
			System.out.println("enter the option:\n 1.Addition\n 2.Subtraction");
			opt=ob.nextInt();
			if(opt==1)
			{
				c=a+b;
				System.out.println(c);
			}
			else
			{    c=a-b;
				System.out.println(c);
			
			}
	}
	

}