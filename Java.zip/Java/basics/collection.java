package basics;
import java.util.*;
public class collection {
	public static void main(String args[])
	{
		List<Integer> a=new ArrayList<Integer>();
		a.add(1);
	/*	a.add("name");*/
		a.add(2);
		System.out.println(a);
		Iterator i=a.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		/*a.add("name1");*/
		ListIterator b=a.listIterator();
		while(b.hasNext()) {
			System.out.println(b.next());
		}
		while(b.hasPrevious()) {
			System.out.println(b.previous());
		}
		System.out.println(a.get(1));
	}
	

}
