package basics;
import java.util.*;
public class collection1 {
public static void main(String args[])
{
	LinkedList l=new LinkedList();
	l.add("a");
	l.add(1);
	l.add(1);
	l.add("name");
	l.addFirst(2);
	l.addLast("m");
	System.out.println(l);
	System.out.println(l.peek());
	System.out.println(l.pollFirst());
	System.out.println(l);
	l.offer(5);
	System.out.println(l);
	Iterator m=l.iterator();
	
	while(m.hasNext())
	{
		System.out.println(m.next());
	}
	ListIterator e=l.listIterator();

}
}
