package basics;
import java.util.*;
public class collection2 {
public static void main(String args[])
{
Set s=new HashSet();	
s.add("strng");
s.add("id");
s.add("ask");
s.add("ask");
System.out.println(s);
Iterator i=s.iterator();
while(i.hasNext())
{
	System.out.println(i.next());
}
Set m=new TreeSet(s);
System.out.println(m);
LinkedHashSet q=new LinkedHashSet();
q.add(1);
q.add(10);
q.add(11);


System.out.println(q);
}
}