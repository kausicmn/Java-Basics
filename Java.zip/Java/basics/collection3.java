package basics;
import java.util.*;
public class collection3 {
public static void  main(String args[])
{
	
	SortedSet s=new TreeSet();
	s.add(2);
	s.add(1);
	s.add(7);
	s.add(5);
	s.add(2);
	System.out.println(s);
	SortedSet t=s.tailSet(2);
	System.out.println(t);
	SortedSet u=s.headSet(2);
	System.out.println(u);
	SortedSet v=s.subSet(2, 7);
	System.out.println(v);
	
}
}
