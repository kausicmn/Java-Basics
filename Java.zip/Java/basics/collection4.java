package basics;
import java.util.*;
public class collection4 {
public static void main(String args[])
{
	 NavigableSet n=new TreeSet();
	 n.add(1);
	
	 n.add(3);
	 n.add(4);
	 n.add(0);
	 System.out.println(n);
	 System.out.println(n.floor(3));
	 System.out.println(n.lower(3));
	 System.out.println(n.ceiling(3));
	 System.out.println(n.higher(3));
}
}
