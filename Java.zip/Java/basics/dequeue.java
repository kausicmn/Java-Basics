package basics;
import java.util.*;

public class dequeue {
	public static void main(String args[])
	{
		Deque l=new LinkedList();
		l.add("a");
	l.add(1);
	l.add(1);
	l.add("name");
	l.addFirst(2);
	l.addLast("m");
	l.push(11);
	System.out.println(l);
	Iterator i=l.descendingIterator();
	{
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
		System.out.println(l.peek());
		System.out.println(l);
		System.out.println(l.pop());
		System.out.println(l);
	}
	
}
