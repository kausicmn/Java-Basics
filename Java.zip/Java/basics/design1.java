package basics;
import java.util.*;
public class design1 {
public static void main(String args[])
{
	int n=0;
	Scanner ob=new Scanner(System.in);
	n=ob.nextInt();
int	t=n*2;
	int m;
	m=n-1;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=t;j++)
		{
		if(i+j>=n-1 && i+j<=m)
		{
			System.out.print("*");
		}
		else
		{
			System.out.print(" ");
		}
			
		}
		m=m+2;
		System.out.println();
	}
}
}

