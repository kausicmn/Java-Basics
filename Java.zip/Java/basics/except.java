package basics;

public class except {
void fun()
{
	try
	{
		int a=67/0;
		System.out.println(a);
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	finally
	{
		System.out.println("the end");
	}
}
public static void main(String args[])
{
	except f=new except();
	f.fun();
}
}
