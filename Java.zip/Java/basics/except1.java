package basics;

public class except1 {
	void bun()
	{
		try
		{
			int a=67/0;
			System.out.println(a);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		finally
		{
			System.out.println("the end");
		}
	}
	public static void main(String args[])
	{
		except1 f=new except1();
		f.bun();
	}
	}