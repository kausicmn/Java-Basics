package basics;

public class except2 {
	void gun()
	{
		try
		{
			int a=67/0;
			System.out.println(a);
		}
	
		finally
		{
			System.out.println("the end");
		}
	}
	public static void main(String args[])
	{
		except2 f=new except2();
		f.gun();
	}
	}


