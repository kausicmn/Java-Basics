package basics;
import java.util.*;

public class fact {
	int i=1;
	
	int fact=1;
int factorial(int n)
	{
		
		while(i<=n)
		{
	
			fact=fact*i;
			i=i+1;
			}
		System.out.println("the factorial is "+fact);
		return fact;
	}
	void display(int fact)
	{
		
		System.out.println("the factorial is "+fact);
	
	}
public static void main(String []args)
{
	int n;
System.out.println("enter the number");
Scanner ob= new Scanner(System.in);

n=ob.nextInt();

fact f=new fact();

int answer=f.factorial(n);
System.out.println(+answer);
f.display(answer);


}
}
