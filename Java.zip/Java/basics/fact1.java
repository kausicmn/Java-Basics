package basics;

import java.util.Scanner;

public class fact1 {
public static void main(String[]args)
{
	int i=1;
	int n;
	int fact=1;
	System.out.println("enter the number");
	Scanner ob= new Scanner(System.in);

	n=ob.nextInt();
	while(i<=n)
	{

		fact=fact*i;
		i=i+1;
		

}
	System.out.println("the factorial is "+fact);
}
}
