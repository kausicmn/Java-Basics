package basics;
import java.util.*;
public class fibonacci {
	int n,c;
	int i=1;
	int a=0;
	int b=1;
	
	void fib(int n)
	{
		if(n==1)
		{
			System.out.println(+a);
		}
		if(n==2)
		{
			System.out.println(+a);
			System.out.println(+b);
		}
		if(n>2)
		{
			System.out.println(+a);
			System.out.println(+b);	
		
		while(i<=n)
		{
		c=a+b;
		a=b;
		b=c;
		i=i+1;
		System.out.println(+c);
		}
		}
		
		

		

	}
	public static void main(String []args)
	{
		int n;
		System.out.println("enter the number");
		Scanner ob=new Scanner(System.in);
		n=ob.nextInt();
		fibonacci fb=new fibonacci();
		fb.fib(n);
		
		
	}

}
