package basics;
class pig
{
	void bark()
	{
		System.out.println("bark");
	}
}
	class cat extends pig
	{
		void dark()
		{
			System.out.println("dark");
		}
	}

public class hh extends pig{
	

public static void main(String args[])
{
hh m=new hh();
cat c=new cat();
c.dark();
m.bark();
}
}

