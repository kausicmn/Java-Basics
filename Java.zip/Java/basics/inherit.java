package basics;
class sal
{
	float salary= 1000;
}
public class inherit extends sal {
int uu=100;

	public static void main(String args[])
	{
		inherit i=new inherit();
		
		System.out.println(i.uu);
		System.out.println(i.salary);
	}
}
