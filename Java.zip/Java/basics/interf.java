package basics;
interface shape
{
	void colour(String s);
	void area(int r);
}
class sqr implements shape
{
	double ar;
	public void colour(String s)
	{
		System.out.println(s);
	}

	@Override
	public void area(int r) {
		ar=3.14*r*r;
		System.out.println(ar);
		
	}
	
}
public class interf {
public static void main(String args[])
{
	shape s=new sqr();
	s.colour("blue");
	s.area(4);
}

}
