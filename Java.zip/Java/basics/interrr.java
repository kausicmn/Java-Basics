package basics;
interface md
{
	void read();
}
interface cd
{
	void draw();
	int s=1000;
}
public class interrr implements cd,md

{
	public void draw()
	{
		System.out.println("rr");
	}
	
	@Override
	public void read() {
		
		System.out.println("ww");
	}
	public static void main(String args[])
	{
		interrr i=new interrr();
		i.read();
		i.draw();
		System.out.println(i.s+5);
	}

}
