package basics;
import java.util.*;

public class map {
public static void main(String args[])
{
	Map m=new HashMap();
	m.put("a",1);
	m.put("b",2);
	m.put("c",3);
	m.put("d",4);
	System.out.println(m);
	Set<HashMap.Entry> st=m.entrySet();
Iterator sm= m.entrySet().iterator();
	while(sm.hasNext())
	{
		System.out.println(sm.next());
	}
	System.out.println(st);
	for (HashMap.Entry me:st)
	{
		System.out.println(me.getKey());
		System.out.println(me.getValue());
	}
}
}
