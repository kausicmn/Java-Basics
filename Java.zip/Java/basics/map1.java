package basics;
import java.util.*;

public class map1 {
	public static void main(String args[])
	{
		LinkedHashMap l=new LinkedHashMap();
		l.put("e", 5);
		l.put("f",7);
		l.put("g",9);
		l.put("h",10);
		System.out.println(l);
		Set<Map.Entry>ww=l.entrySet();
		for(Map.Entry qq:ww)
		{
			System.out.println(qq.getKey());
			System.out.println(qq.getValue());
		}
		System.out.println(l.get("e"));
		System.out.println(l.isEmpty());
		System.out.println(l.containsKey("u"));
		System.out.println(l.containsValue(10));
		System.out.println(l.remove("g"));
		System.out.println(l);
		}

}
