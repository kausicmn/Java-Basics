package basics;
import java.util.*;
public class map2 {

public static void main(String args[])
{
	TreeMap t=new TreeMap();
	t.put("f", 5);
	t.put("f",7);
	t.put("g",0);
	t.put("a",10);
	System.out.println(t);
	
	Set<Map.Entry> ss=t.entrySet();
	for(Map.Entry aa:ss)
	{
		System.out.println(aa.getKey());
		System.out.println(aa.getValue());
	}
	System.out.println(t.firstKey());
	
	
}

}
