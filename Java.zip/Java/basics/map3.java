package basics;
import java.util.*;
public class map3 {
	
	
	
	public static void  main(String args[])
	{
		
		SortedMap s=new TreeMap();
		s.put(2,"add");
		s.put(1,"sub");
		s.put(7,"mul");
		s.put(5,"div");
		
		System.out.println(s);
		SortedMap t=s.tailMap(2);
		System.out.println(t);
		SortedMap u=s.headMap(2);
		System.out.println(u);
		SortedMap v=s.subMap(2, 7);
		System.out.println(v);
		 
		 {
			 
		 }
	}
	}


