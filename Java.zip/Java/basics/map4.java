package basics;
import java.util.*;
public class map4 {
	

	
	public static void main(String args[])
	{
		 NavigableMap<Integer,String> n=new TreeMap();
		 n.put(2,"add");
		n.put(1,"sub");
			n.put(7,"mul");
			n.put(5,"div");
		 System.out.println(n);
		 System.out.println(n.floorKey(2));
		 System.out.println(n.headMap(2));
		 System.out.println(n.ceilingKey(2));
		 System.out.println(n.tailMap(2));
		 for(Map.Entry<Integer,String> ss:n.entrySet())
		 {
			 System.out.println(ss.getKey());
			 System.out.println(ss.getValue());
			 
		 }
	}
	}


