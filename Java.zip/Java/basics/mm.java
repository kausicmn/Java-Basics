package basics;
class mouse
{
	void odd()
	{
		System.out.println("odd");
	}
}
class rat extends mouse
{
	void even()
	{
		System.out.println("even");
	}
}
public class mm extends rat {
public static void main(String args[])
{
	mm h=new mm();
	h.even();
	
	h.odd();
}
}
