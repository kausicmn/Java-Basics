package basics;
import java.util.Scanner;
public class neww {
	



	    public static void main(String[] args) {
	        Scanner scan = new Scanner(System.in);
	        
	       int i = scan.nextInt();
	        String s=scan.nextLine();
	       /* s=scan.nextLine();*/
	       Double d=scan.nextDouble();


	        

	        System.out.println("String: " +s);
	        System.out.println("Double: " +d);
	        System.out.println("Int: " +i);
	    }
	}

