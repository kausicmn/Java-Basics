package basics;

public class overloading{

	void load(int n,char j)
	{
		System.out.println(n +""+j);
	}
	void load(char j,int n)
	{
		System.out.println(j+""+n);
	}

 
	public static void main(String args[])
	{
		overloading o =new overloading();
		o.load(1,'a');
		o.load('a', 2);
	}
	}

