package basics;
class under
{
	void disp()
	{
		System.out.println("name");
	}
}
public class overriding extends under {

	void disp()
	{
		System.out.println("name1");
	}
	void neww()
	{
		System.out.println("new");
		
	}
	public static void main(String args[])
	{
		under u=new overriding();
		u.disp();
		
		
		
	}
}
