package basics;
import java.util.*;
public class prime {
	int n,i,flag=0;
	void primenumber(int n)
	{
		for(i=2;i<n/2;i++)
		{
			System.out.println("a");
			if(n%i==0)
			{
				flag=1;
				System.out.println("the number is not a prime");
				break;
			}
		}
				if(flag==0)
				{
					System.out.println("the number is prime");
					
		}
	}
public static void main(String args[])
{
	int n;
	System.out.println("enter the number");
	Scanner ob=new Scanner(System.in);
	n=ob.nextInt();
	prime p=new prime();
	p.primenumber(n);
	
}
}

