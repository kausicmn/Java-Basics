package basics;


import java.util.Scanner;
public class prime1 {
	int n,i,flag=0;
	int t;
	void primenumber(int n)
	{
		for(i=2;i<n/2;i++)
		{
			if(n%i==0)
			{
				flag=1;
				System.out.println("the number is not a prime");
				break;
			}
		}
				if(flag==0)
				{
					
					System.out.println("the number is prime "+t);
					
		}
				
	}
public static void main(String args[])
{
	int n;
	int ans;
	System.out.println("enter the number");
	Scanner ob=new Scanner(System.in);
	n=ob.nextInt();
	prime p=new prime();
   p.primenumber(n);
	
}
}

