package basics;
import java.util.*;
public class queue {
	public static void main(String args[])
	{
		Queue q=new LinkedList();
		q.add(1);
		for(int i=0;i<5;i++)
		{
			q.add(i);
		}
		System.out.println(q);
		System.out.println(q.remove());
		System.out.println(q);
		System.out.println(q.peek());
	}
	

}
