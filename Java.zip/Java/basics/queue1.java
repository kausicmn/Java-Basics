package basics;
import java.util.*;
public class queue1 {
	

	
		public static void main(String args[])
		{
			PriorityQueue q=new PriorityQueue();
			q.add(1);
			
			for(int i=0;i<5;i++)
			{
				q.add(i);
			}
			System.out.println(q);
			System.out.println(q.remove());
			System.out.println(q);
			System.out.println(q.peek());
			System.out.println(q.remove());
			Iterator i=q.iterator();
			{
				while(i.hasNext())
				{
					System.out.println(i.next());
				}
			}
			
		}
		
}
