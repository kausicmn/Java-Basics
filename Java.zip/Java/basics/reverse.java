package basics;

import java.util.Scanner;

public class reverse {
int temp;
int rev=0;
int rev(int n)
{
	
while(n!=0)	
{
	rev=rev*10;
	rev=rev+n%10;
	n=n/10;
	
}
System.out.println("the reverse is "+rev);
return rev;
}
void palindrome(int temp,int rev)
{
	if(temp==rev)
	{
		System.out.println("palindrome");
		
	}
	else
	{
		System.out.println("Not palindrome");
	}
		
}

public static void main(String args[])
{
int n,temp,r;
System.out.println("enter the number");
Scanner ob=new Scanner(System.in);
n=ob.nextInt();
temp=n;
reverse p=new reverse();
r=p.rev(n);

p.palindrome(temp,r);
}

	
}