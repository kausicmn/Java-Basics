
package basics;


import java.util.Scanner;
public class reverseprime {
	int n,i,flag=0;
	int t;
	static int f;
	int revprime(int n)
	{
		for(i=2;i<=n/2;i++)
		{
			if(n%i==0)
			{
				flag=1;
				System.out.println("the number is not a prime");
				break;
			}
		}
				if(flag==0)
				{
					f=1;
					t=n;
				
					
		}
				return t;
				
	}
	int isprime(int p)
	{
		int a,b,c;
		a=p%10;
		b=p/10;
		c=a+b;
		f=0;
		return c;
		
	}
public static void main(String args[])
{
	int n;
	int ans;
	int pr;
	System.out.println("enter the number");
	Scanner ob=new Scanner(System.in);
	n=ob.nextInt();
	reverseprime p=new reverseprime();
    ans=p.revprime(n);
   pr= p.isprime(ans);
   p.revprime(pr);
   if(f==1)
	   
   System.out.println("the number is prime");
	
	
}
}
