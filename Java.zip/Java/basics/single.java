package basics;
class dog{
	
void play()
{
System.out.println("play");

	
}
}

public class single extends dog {
	void eat()
	{
		System.out.println("eat");
	}
	public static   void main(String args[])
	{
		single c=new single();
		c.eat();
		c.play();
	}
}


