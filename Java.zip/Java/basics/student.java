package basics;
import java.util.*;
public class student {
	int id,i,sub1,sub2,sub3;
	int total=0;
	String name,n;
	static Scanner st=new Scanner(System.in);
	int[] arr=new int[3];
	
	
	student()
	{
	System.out.println("enter the student name and id");
	
	name=st.next();
	id=st.nextInt();
	i=id;
	n=name;
		
	}
	void detail() {
		
			
	System.out.println("enter the student marks");
	
		sub1=st.nextInt();
		
		sub2=st.nextInt();
		
		sub3=st.nextInt();
		
		total=sub1+sub2+sub3;
		System.out.println("Sname="+name+"\n"+ "sid="+id+'\n'+"sub1="+sub1+'\n'+"sub2="+sub2+'\n'+
				"sub3="+sub3+'\n'+"total="+total);
		
		
				
	}
	
	


	


public static void main (String[] args)
{
	
	
	student s=new student();
	s.detail();
	student s2=new student();
	
	
	s2.detail();
	
}
}