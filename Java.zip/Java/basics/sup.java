package basics;
class ele
{
	
	int s=100;
	
}
class rep extends ele
{
	void md()
	{
		int s=1000;
		System.out.println(super.s);
		System.out.println(s);
	}
}
public class sup {

	public static void main(String args[])
	{
		rep r=new rep();
		r.md();
	}
}
