package basics;
import java.util.Scanner;



public class tcs {
public static void main(String[]args)
{
int n;
Scanner s=new Scanner(System.in);
n=s.nextInt();
int[]a=new int[n];
String[]x=new String[n];
String[]num= {"zero","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","nineteen","twenty", "twentyone","twentytwo","twentythree","twentyfour"," twentyfive", "twentysix", "twentyseven","twentyeight","twentynine","thirty","thirtyone","thirtytwo","thirtythree","thirtyfour","thirtyfive","thirtysix","thirtyseven","thirtyeight","thirtynine","forty","fortyone","fortytwo","fortythree","fortyfour","fortyfive","fortysix","fortyseven","fortyeight","fortynine","fifty","fiftyone","fiftytwo","fiftythree","fiftyfour","fiftyfive","fiftysix","fiftyseven","fiftyeight","fiftynine","sixty","sixtyone","sixtytwo","sixtythree","sixtyfour","sixtyfive","sixtysix","sixtyseven","sixtyeight","sixtynine","seventy","seventyone","seventytwo","seventythree","seventyfour","seventyfive","seventysix","seventyseven","seventyeight","seventynine","eighty","eightyone","eightytwo","eightythree","eightyfour","eightyfive","eightysix","eightyseven","eightyeight","eightynine","ninety","ninetyone","ninetytwo","ninetythree","ninetyfour","ninetyfive","ninetysix","ninetyseven","ninetyeight","ninetynine","hundred"};
for(int i=0;i<n;i++)
{
a[i]=s.nextInt();
x[i]=num[a[i]];
}
int r=0;
for(int i=0;i<n;i++)
{

for(int j=0;j<x[i].length();j++)
{
char y=x[i].charAt(j);
if(y=='a'||y=='e'||y=='i'||y=='o'||y=='u')
{
r++;

}
}

}
int p=0;
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
if(a[i]+a[j]==r)
{
p++;

}

}
}
System.out.println(num[p]);
}




}

