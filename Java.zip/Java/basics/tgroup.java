package basics;

	public class tgroup implements Runnable{
	public static void main(String args[])
	{
		tgroup t=new tgroup();
		ThreadGroup tg1=new ThreadGroup("parent group");
		Thread t1=new Thread(tg1,t,"first");
		Thread t2=new Thread(tg1,t,"Second");
		Thread t3=new Thread(tg1,t,"third");
		t1.start();
		t2.start();
		t3.start();
		System.out.println(tg1.getName());
		tg1.list();
	}
	 public void run()
	{
		System.out.println(Thread.currentThread().getName());
	}
	}


