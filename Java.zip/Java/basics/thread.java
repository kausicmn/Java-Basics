package basics;

/*public class thread extends Thread  {*/

 
public class thread implements Runnable{

	public void run()
	{
		for(int i=0;i<5;i++)
		{
		/*try {
			Thread.sleep(1000);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}*/
		System.out.println(Thread.currentThread().getName()+"id="+Thread.currentThread().getId()+"priority="+Thread.currentThread().getPriority());
	}}
	  public static void main(String args[]) throws Exception
	{
		thread t=new thread();
		Thread t3=new Thread(t);
		t3.setName("thread1");
		
		/*t3.setPriority(Thread.MAX_PRIORITY);*/
		
		Thread t4=new Thread(new thread());
		t4.setName("thread2");
		/*t3.join();*/
		
		
		

		t3.start();
		t4.start();
		/*t3.yield();*/
	}
}
