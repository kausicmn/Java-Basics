package basics;
import java.util.*;
public class thread1 implements Runnable {
	int amt=0;
public synchronized void run()
{
	if(Thread.currentThread().getName().equals("withdraw"))
			
	{
		System.out.println("enter amount to be withdraw");
	
		
	if(amt<5000)
	{
		amt=amt-5000;
		try
		{
			
			
			System.out.println("insuuficient bal");
			wait();
			System.out.println("amount debited"+amt);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	}
			
		else
		{
			System.out.println("enter the amount to be deposited"+amt);
			amt=amt+10000;
			notify();
			System.out.println("amount credited"+amt);
		}
	}
public static void main(String args[])
{
	thread1 t=new thread1();
	Thread t5=new Thread(t);
	
	t5.setName("withdraw");
	Thread t6=new Thread(t);
	t6.setName("deposit");
	t5.start();
	t6.start();
}
}

