package basics;

public class thrw {
int num;
	void pun(int n)
	{
		
		if(n<25)
		{
			throw new ArrayIndexOutOfBoundsException("not vaild");
		}
		else {
			System.out.println("valid");
		}
	}
	
	public static void main(String args[])
	{
		thrw t=new thrw();
		t.pun(15);
	}
}
