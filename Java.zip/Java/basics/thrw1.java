package basics;

public class thrw1 {
static void sun()
{
	try
	{
		throw new NullPointerException("null");
	}
	catch(Exception e)
	{
		System.out.println("occured");
		throw e;
	}
	
}
public static void main(String args[])
{
	try
	{
		sun();
		
	}
	catch(NullPointerException e)
	{
		System.out.println(e);
	}
	finally
	{
		System.out.println("done");
	}
}
}
