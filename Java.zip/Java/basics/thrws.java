package basics;

public class thrws {
 static void ant ()throws Exception
{
	 try
	 {
		 throw new ArithmeticException("exception occured"); 
	 }
	
	 catch (Exception e)
	 {
		 System.out.println(e);
		 
	 }
}
public static void main(String args[])throws Exception
{
	ant();
}
}
