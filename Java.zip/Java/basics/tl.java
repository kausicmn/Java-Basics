package basics;


 class cl {
private String name;
private int id;
public String getName() {
	return name;
}
public void setName(String a) {
	name=a;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

}

public class tl {
public static void main(String args[])
{
cl n=new cl();
n.setName("muthu");
n.setId(100);
System.out.println(n.getName());
System.out.println(n.getId());
}
}
