package basics;
 class reserve 
{
	

 static int available=10;
	   synchronized void reserved(int s)
	{
		   System.out.println("the current thread enterted is"+Thread.currentThread().getName());
		   
		if(s>available)
		{
			System.out.println("seat not avaliable");
			
		}
		if(s<=available)
		{
			available=available-s;
			
			System.out.println("seat reserved");
			
		}
		System.out.println("seats left"+available);
		System.out.println("thread leaving"+Thread.currentThread().getName());
		System.out.println("----------------------------------------------");
	}
	
}
  class person extends Thread
{
	/*reserve r=new reserve ();*/
	  reserve r;
	int reqseats;
	
person( reserve r,int req)
{
	reqseats=req;
	this.r=r;
}
	@Override
	public void run() {
	r.reserved(reqseats);
		
	}
	
}
	   public class train  {
 public static void main(String args[])
{
	 reserve r=new reserve();
	 person t1=new person(r,5);
	 t1.setName("tt1");
	 t1.start();
	
	person t2=new person(r,4);
	t2.setName("tt2");
	t2.start();
	person t3=new person(r,2);
	t3.setName("tt3");
	t3.start();
	
	
}
	
	   }


